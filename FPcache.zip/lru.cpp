#include "lru.hpp"

LRUItem::LRUItem(Item _item)
{
	//pre = _pre;
	item=_item;
	//next = _next;

}
LRUStack::LRUStack():ACC_NUM(0),
HIT_NUM(0),
PAGE_FAULT_NUM(0), 
maxszie(0),
stacksize(0),
root(nullptr),
tail(nullptr) {}
LRUStack::LRUStack(size_t _maxsize) :
	ACC_NUM(0),
	HIT_NUM(0),
	PAGE_FAULT_NUM(0),
	maxszie(_maxsize),
	stacksize(0),
	root(nullptr),
	tail(nullptr)
{
	ptrvec.clear();
}
void LRUStack::setMaxSize(size_t _maxsize) {
	maxszie = _maxsize;
}
bool LRUStack::isFull()
{
	return (maxszie== stacksize);
}

bool LRUStack::isEmpty()
{
	return (stacksize==0);
}
bool LRUStack::evict()
{
	if(!tail)
		return false;
	else
	{
		LRUItem* temp= tail;
		tail->pre->next = tail->next;
		tail = tail->pre;
		ptrvec.erase(temp->item);
		stacksize--;
		delete temp;
		return true;
	}
}

bool LRUStack::evict(Item _it)
{
	if (ptrvec[_it] != nullptr)
	{
		if (ptrvec[_it] == root) {
			root = (*ptrvec[_it]).next;
			(*ptrvec[_it]).next->pre = nullptr;
			free(ptrvec[_it]);
		}
		else if (ptrvec[_it] == tail)
		{
			tail = ptrvec[_it]->pre;
			ptrvec[_it]->pre->next = ptrvec[_it]->next;
			free(ptrvec[_it]);
		}
		else if (ptrvec[_it] != this->end())
		{
			ptrvec[_it]->pre->next = ptrvec[_it]->next;
			ptrvec[_it]->next->pre = ptrvec[_it]->pre;
			free(ptrvec[_it]);
		}
		ptrvec.erase(_it);
		stacksize--;
		return true;
	}
	return false;
}

bool LRUStack::pageFault(Item _item)
{
	PAGE_FAULT_NUM++;
	if (isFull()){//��������
		if (!evict())
			return false;
	}
	else if (isEmpty()) {
		LRUItem* item = new LRUItem(_item);
		if (!item)
			return false;
		item->next = tail;
		tail = item;
		root = item;
		ptrvec[_item]= item;
		stacksize++;
		return true;
	}
	LRUItem *nitem = new LRUItem(_item);
	if (!nitem)
		return false;
	(*root).pre = nitem;
	(*nitem).next = root;
	root = nitem;
	ptrvec[_item] = nitem;
	stacksize++;
	return true;
}
void LRUStack::stateReset()
{
	ACC_NUM = 0;
	HIT_NUM = 0;
	PAGE_FAULT_NUM = 0;
}
bool LRUStack::access(Item _item)
{
	ACC_NUM++;
	if (_item!="")
	{
		auto it=ptrvec.find(_item);
		if (it!= ptrvec.end()) {//����
			HIT_NUM++;
			if ((*it).second == root) {
				return true;
			}
			else if ((*it).second == tail) {//����β���
				(*it).second->pre->next = (*it).second->next;
				tail = (*it).second->pre;
			}
			else
			{
				(*it).second->pre->next = (*it).second->next;
				(*it).second->next->pre = (*it).second->pre;
			}//LRUItem Item=(*(*it).second);			
			(*root).pre = (*it).second;
			(*it).second->pre = nullptr;
			(*it).second->next = root;
			root = (*it).second;
			return true;
		}
		else {
			pageFault(_item);
		}
	}
	else
		return false;
}

uint64_t LRUStack::stateACC()
{
	return ACC_NUM;
}

uint64_t LRUStack::stateHIT()
{
	return HIT_NUM;
}

uint64_t LRUStack::stateFault()
{
	return PAGE_FAULT_NUM;
}

void LRUStack::flush()
{
	LRUItem* pPtr = root;
	LRUItem* tempPtr = nullptr;
	while (pPtr)
	{
		tempPtr = pPtr->next;
		free(pPtr);
		pPtr=tempPtr;
		stacksize--;
	}
}

size_t LRUStack::getCacheSize()
{
	return stacksize;
}







